const decode = (value) => Uint8Array.from(atob(value), c => c.charCodeAt(0));
const TEXT = new TextDecoder();
const HTML = TEXT.decode(decode("__HTML_B64__"));
const CSS = TEXT.decode(decode("__CSS_B64__"));
const APP_JS = TEXT.decode(decode("__JS_B64__"));
const HERO = decode("__HERO_B64__");

const LOGIN_HTML = `<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>公考智学 · 登录</title><style>
*{box-sizing:border-box}body{margin:0;min-height:100vh;font-family:Inter,"Noto Sans SC",system-ui,sans-serif;color:#173f38;background:linear-gradient(135deg,#edf4ea,#f8f3e8 55%,#dceee0);display:grid;place-items:center;padding:24px}.shell{width:min(980px,100%);min-height:600px;display:grid;grid-template-columns:1.08fr .92fr;overflow:hidden;border-radius:28px;background:#fffdf8;box-shadow:0 24px 80px #174d3b24}.visual{padding:48px;display:flex;flex-direction:column;justify-content:space-between;background:linear-gradient(145deg,#125449,#2d725d);color:#fff;position:relative;overflow:hidden}.visual:after{content:"";position:absolute;width:420px;height:420px;border-radius:50%;right:-170px;bottom:-190px;background:#cde87f33}.brand{font-size:22px;font-weight:800;letter-spacing:.04em}.visual h1{font-size:42px;line-height:1.18;margin:0 0 18px;max-width:390px}.visual p{font-size:16px;line-height:1.9;color:#d7eee2;max-width:390px}.study{font-size:82px;opacity:.95}.card{padding:64px 58px;display:flex;flex-direction:column;justify-content:center}.eyebrow{font-size:12px;letter-spacing:.2em;color:#6aa163;font-weight:700}.card h2{font-size:30px;margin:12px 0 8px}.sub{color:#71817d;line-height:1.7;margin:0 0 28px}.field{display:block;margin:14px 0 8px;font-size:13px;color:#50625d}.input{width:100%;height:52px;padding:0 16px;border:1px solid #d5dfd8;border-radius:12px;font-size:16px;outline:none}.input:focus{border-color:#2c7460;box-shadow:0 0 0 4px #2c746014}.row{display:flex;gap:10px}.row .input{flex:1}.btn{border:0;border-radius:12px;background:#14584c;color:white;font-weight:700;font-size:16px;padding:0 20px;cursor:pointer}.btn:disabled{opacity:.55;cursor:not-allowed}.submit{width:100%;height:52px;margin-top:22px}.hint{font-size:12px;color:#8a9792;margin-top:18px;line-height:1.7}.msg{min-height:22px;color:#b34f45;font-size:13px;margin-top:10px}.hidden{display:none}@media(max-width:760px){.shell{grid-template-columns:1fr}.visual{min-height:240px;padding:30px}.visual h1{font-size:30px}.study{font-size:54px}.card{padding:38px 26px}}
</style></head><body><main class="shell"><section class="visual"><div class="brand">公考智学 <small>GONGKAO AGENT</small></div><div><div class="study">📚</div><h1>每天 5 题，稳步上岸。</h1><p>错题复盘、AI 答疑与学习进度，都在一个安静的备考空间里完成。</p></div></section><section class="card"><div class="eyebrow">GONGKAO STUDY ASSISTANT</div><h2>邮箱登录</h2><p class="sub">输入邮箱获取一次性验证码，登录后即可开始今天的练习。</p><form id="form"><label class="field" for="email">邮箱地址</label><input class="input" id="email" type="email" autocomplete="email" placeholder="name@example.com" required><div id="codeWrap" class="hidden"><label class="field" for="code">邮箱验证码</label><div class="row"><input class="input" id="code" inputmode="numeric" maxlength="6" placeholder="6 位验证码"><button class="btn" id="resend" type="button">重新发送</button></div></div><div id="msg" class="msg"></div><button class="btn submit" id="submit" type="submit">获取验证码</button></form><p class="hint">验证码有效期 10 分钟。我们不会向外公开你的邮箱。</p></section></main><script>
const $=s=>document.querySelector(s), form=$('#form'), email=$('#email'), code=$('#code'), wrap=$('#codeWrap'), msg=$('#msg'), submit=$('#submit'), resend=$('#resend'); let sent=false, busy=false;
function message(t,error=true){msg.textContent=t;msg.style.color=error?'#b34f45':'#4d8060'}
async function call(path,body){const r=await fetch(path,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body)});return {ok:r.ok,data:await r.json().catch(()=>({}))}}
async function send(){const value=email.value.trim();if(!value||!email.checkValidity())return message('请输入有效的邮箱地址');busy=true;resend.disabled=true;submit.disabled=true;message('正在发送验证码…',false);const r=await call('/api/auth/request-code',{email:value});busy=false;resend.disabled=false;submit.disabled=false;if(!r.ok){return message(r.data.message||'验证码发送失败，请稍后重试')}sent=true;wrap.classList.remove('hidden');code.focus();submit.textContent='登录';message('验证码已发送，请查收邮箱。',false)}
form.addEventListener('submit',async e=>{e.preventDefault();if(busy)return;if(!sent)return send();const value=code.value.trim();if(!/^\\d{6}$/.test(value))return message('请输入 6 位验证码');busy=true;submit.disabled=true;message('正在登录…',false);const r=await call('/api/auth/verify-code',{email:email.value.trim(),code:value});if(r.ok){location.href='/';return}busy=false;submit.disabled=false;message(r.data.message||'验证码错误，请重试')});resend.addEventListener('click',send);
</script></body></html>`;

const json = (data, status = 200) => new Response(JSON.stringify(data), {
  status,
  headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" }
});

async function hashText(value) {
  const bytes = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value));
  return [...new Uint8Array(bytes)].map(byte => byte.toString(16).padStart(2, "0")).join("");
}

function cookieValue(request, name) {
  const cookie = request.headers.get("cookie") || "";
  const match = cookie.match(new RegExp(`(?:^|;\\s*)${name}=([^;]+)`));
  return match ? decodeURIComponent(match[1]) : "";
}

async function visitor(request, env) {
  const sessionToken = cookieValue(request, "gk_session");
  if (sessionToken) {
    const tokenHash = await hashText(sessionToken);
    const session = await env.DB.prepare(`SELECT s.user_id, u.email, u.display_name FROM auth_sessions s JOIN students u ON u.user_id=s.user_id WHERE s.token_hash=? AND s.expires_at > CURRENT_TIMESTAMP`).bind(tokenHash).first();
    if (session) return { userId: session.user_id, email: session.email, name: session.display_name || session.email.split("@")[0] };
  }
  const userId = request.headers.get("oai-authenticated-user-id");
  const email = request.headers.get("oai-authenticated-user-email");
  if (!userId || !email) return null;
  const rawName = request.headers.get("oai-authenticated-user-full-name");
  let name = email.split("@")[0];
  if (rawName) {
    try { name = decodeURIComponent(rawName); } catch { name = rawName; }
  }
  return { userId, email, name };
}

async function ensureStudent(env, user) {
  await env.DB.prepare(`INSERT INTO students (user_id, email, display_name, last_seen_at)
    VALUES (?, ?, ?, CURRENT_TIMESTAMP)
    ON CONFLICT(user_id) DO UPDATE SET email=excluded.email, display_name=excluded.display_name, last_seen_at=CURRENT_TIMESTAMP`)
    .bind(user.userId, user.email, user.name).run();
}

function beijingDate(now = new Date()) {
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone: "Asia/Shanghai", year: "numeric", month: "2-digit", day: "2-digit"
  }).formatToParts(now);
  const value = Object.fromEntries(parts.map(part => [part.type, part.value]));
  return `${value.year}-${value.month}-${value.day}`;
}

async function ensureDailyQuestionSet(env, studyDate) {
  const existing = await env.DB.prepare(`SELECT COUNT(*) AS count FROM daily_question_sets WHERE study_date = ?`)
    .bind(studyDate).first();
  if (Number(existing?.count || 0) >= 5) return;
  const candidates = await env.DB.prepare(`SELECT id FROM question_bank WHERE active = 1 ORDER BY id`).all();
  const shuffled = [...(candidates.results || [])];
  let seed = Number(studyDate.replaceAll("-", "")) >>> 0;
  for (let index = shuffled.length - 1; index > 0; index--) {
    seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
    const swapIndex = seed % (index + 1);
    [shuffled[index], shuffled[swapIndex]] = [shuffled[swapIndex], shuffled[index]];
  }
  const selected = shuffled.slice(0, 5);
  if (selected.length < 5) throw new Error("question_bank_requires_five_active_questions");
  await env.DB.batch(selected.map((row, position) => env.DB.prepare(`INSERT OR IGNORE INTO daily_question_sets
    (study_date, position, question_id) VALUES (?, ?, ?)`).bind(studyDate, position, row.id)));
}

async function api(request, env, url) {
  if (url.pathname === "/api/auth/request-code" && request.method === "POST") {
    const body = await request.json().catch(() => ({}));
    const email = String(body.email || "").trim().toLowerCase();
    if (!/^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/.test(email)) return json({ error: "invalid_email", message: "请输入有效的邮箱地址" }, 400);
    if (!env.RESEND_API_KEY || !env.EMAIL_FROM) return json({ error: "email_not_configured", message: "邮件服务尚未配置，请联系管理员" }, 503);
    const previous = await env.DB.prepare(`SELECT sent_at FROM email_codes WHERE email=?`).bind(email).first();
    if (previous?.sent_at && Date.now() - Date.parse(previous.sent_at + "Z") < 60_000) return json({ error: "too_frequent", message: "发送过于频繁，请 60 秒后再试" }, 429);
    const code = String(Math.floor(100000 + Math.random() * 900000));
    const codeHash = await hashText(`${email}:${code}`);
    await env.DB.prepare(`INSERT INTO email_codes(email, code_hash, expires_at, sent_at, attempts) VALUES (?, ?, datetime('now','+10 minutes'), CURRENT_TIMESTAMP, 0) ON CONFLICT(email) DO UPDATE SET code_hash=excluded.code_hash, expires_at=excluded.expires_at, sent_at=excluded.sent_at, attempts=0`).bind(email, codeHash).run();
    const mail = await fetch("https://api.resend.com/emails", { method: "POST", headers: { "content-type": "application/json", "authorization": `Bearer ${env.RESEND_API_KEY}` }, body: JSON.stringify({ from: env.EMAIL_FROM, to: [email], subject: "公考智学登录验证码", html: `<div style="font-family:Arial,sans-serif;color:#173f38"><h2>公考智学登录验证码</h2><p>你的验证码是：</p><p style="font-size:32px;font-weight:700;letter-spacing:8px">${code}</p><p>验证码 10 分钟内有效。如非本人操作，请忽略此邮件。</p></div>` }) });
    if (!mail.ok) { console.error("email provider error", await mail.text().catch(() => "")); return json({ error: "email_send_failed", message: "邮件发送失败，请稍后重试" }, 502); }
    return json({ ok: true });
  }
  if (url.pathname === "/api/auth/verify-code" && request.method === "POST") {
    const body = await request.json().catch(() => ({}));
    const email = String(body.email || "").trim().toLowerCase(), code = String(body.code || "").trim();
    const record = await env.DB.prepare(`SELECT code_hash, expires_at, attempts FROM email_codes WHERE email=?`).bind(email).first();
    if (!record || Date.parse(String(record.expires_at).replace(" ", "T") + "Z") < Date.now() || Number(record.attempts) >= 5) return json({ error: "code_expired", message: "验证码已失效，请重新获取" }, 400);
    const valid = await hashText(`${email}:${code}`) === record.code_hash;
    if (!valid) { await env.DB.prepare(`UPDATE email_codes SET attempts=attempts+1 WHERE email=?`).bind(email).run(); return json({ error: "code_invalid", message: "验证码不正确，请检查后重试" }, 400); }
    const userId = `email:${await hashText(email)}`;
    await env.DB.prepare(`INSERT INTO students(user_id,email,display_name,last_seen_at) VALUES(?,?,?,CURRENT_TIMESTAMP) ON CONFLICT(user_id) DO UPDATE SET last_seen_at=CURRENT_TIMESTAMP`).bind(userId, email, email.split("@")[0]).run();
    const sessionToken = crypto.randomUUID() + crypto.randomUUID();
    await env.DB.prepare(`INSERT INTO auth_sessions(token_hash,user_id,expires_at) VALUES(?,?,datetime('now','+30 days'))`).bind(await hashText(sessionToken), userId).run();
    await env.DB.prepare(`DELETE FROM email_codes WHERE email=?`).bind(email).run();
    return new Response(JSON.stringify({ ok: true }), { headers: { "content-type": "application/json; charset=utf-8", "set-cookie": `gk_session=${encodeURIComponent(sessionToken)}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=2592000` } });
  }
  if (url.pathname === "/api/auth/logout") return new Response(null, { status: 302, headers: { location: "/login", "set-cookie": "gk_session=; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=0" } });
  if (url.pathname === "/api/payments/wechat/notify" || url.pathname === "/api/payments/alipay/notify") {
    return json({ error: "payment_provider_not_configured" }, 503);
  }
  const user = await visitor(request, env);
  if (!user) return json({ authenticated: false }, 401);
  await ensureStudent(env, user);

  if (url.pathname === "/api/me") {
    const stats = await env.DB.prepare(`SELECT COUNT(*) AS answered,
      COALESCE(SUM(is_correct), 0) AS correct FROM daily_progress WHERE user_id = ?`)
      .bind(user.userId).first();
    const wrong = await env.DB.prepare(`SELECT q.id, q.subject, q.prompt AS text, q.option_a, q.option_b,
      q.option_c, q.option_d, q.correct_answer AS answer, q.explanation AS explain
      FROM wrong_questions w JOIN question_bank q ON q.id = w.question_id
      WHERE w.user_id = ? AND w.mastered_at IS NULL ORDER BY w.created_at DESC`).bind(user.userId).all();
    return json({ authenticated: true, user: { name: user.name, email: user.email }, stats, wrongQuestions: wrong.results });
  }

  if (url.pathname === "/api/daily-questions" && request.method === "GET") {
    const studyDate = beijingDate();
    await ensureDailyQuestionSet(env, studyDate);
    const rows = await env.DB.prepare(`SELECT q.id, q.subject, q.section, q.prompt AS text,
      q.option_a, q.option_b, q.option_c, q.option_d, q.correct_answer AS answer,
      q.explanation AS explain, d.position, p.selected_answer
      FROM daily_question_sets d JOIN question_bank q ON q.id = d.question_id
      LEFT JOIN daily_progress p ON p.user_id = ? AND p.study_date = d.study_date AND p.question_id = q.id
      WHERE d.study_date = ? ORDER BY d.position`).bind(user.userId, studyDate).all();
    const questions = rows.results.map(row => ({
      id: row.id, subject: row.subject, section: row.section, text: row.text,
      options: [row.option_a, row.option_b, row.option_c, row.option_d],
      answer: row.answer, explain: row.explain
    }));
    const answers = Object.fromEntries(rows.results.filter(row => row.selected_answer !== null)
      .map(row => [row.id, row.selected_answer]));
    return json({ studyDate, timezone: "Asia/Shanghai", questions, answers });
  }

  if (url.pathname === "/api/progress" && request.method === "POST") {
    const body = await request.json();
    const studyDate = beijingDate();
    const qid = Number(body.questionId), selected = Number(body.selectedAnswer);
    if (!Number.isInteger(qid) || !Number.isInteger(selected)) return json({ error: "invalid_answer" }, 400);
    if (selected < 0 || selected > 3) return json({ error: "invalid_answer" }, 400);
    await ensureDailyQuestionSet(env, studyDate);
    const question = await env.DB.prepare(`SELECT q.correct_answer FROM daily_question_sets d
      JOIN question_bank q ON q.id = d.question_id WHERE d.study_date = ? AND q.id = ?`).bind(studyDate, qid).first();
    if (!question) return json({ error: "question_not_in_today_set" }, 400);
    const correct = Number(question.correct_answer) === selected ? 1 : 0;
    await env.DB.prepare(`INSERT INTO daily_progress (user_id, study_date, question_id, selected_answer, is_correct, answered_at)
      VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
      ON CONFLICT(user_id, study_date, question_id) DO UPDATE SET selected_answer=excluded.selected_answer,
      is_correct=excluded.is_correct, answered_at=CURRENT_TIMESTAMP`)
      .bind(user.userId, studyDate, qid, selected, correct).run();
    if (!correct) await env.DB.prepare(`INSERT INTO wrong_questions (user_id, question_id, created_at, mastered_at)
      VALUES (?, ?, CURRENT_TIMESTAMP, NULL)
      ON CONFLICT(user_id, question_id) DO UPDATE SET mastered_at=NULL, created_at=CURRENT_TIMESTAMP`).bind(user.userId, qid).run();
    else await env.DB.prepare(`DELETE FROM wrong_questions WHERE user_id=? AND question_id=?`).bind(user.userId, qid).run();
    return json({ ok: true, isCorrect: Boolean(correct), studyDate });
  }

  if (url.pathname.startsWith("/api/wrong/") && request.method === "DELETE") {
    const qid = Number(url.pathname.split("/").pop());
    await env.DB.prepare(`UPDATE wrong_questions SET mastered_at=CURRENT_TIMESTAMP WHERE user_id=? AND question_id=?`).bind(user.userId, qid).run();
    return json({ ok: true });
  }

  if (url.pathname === "/api/ai-question" && request.method === "POST") {
    const body = await request.json();
    const question = String(body.question || "").trim().slice(0, 2000);
    const answer = String(body.answer || "").trim().slice(0, 6000);
    if (!question) return json({ error: "empty_question" }, 400);
    await env.DB.prepare(`INSERT INTO ai_questions (user_id, question_text, answer_text) VALUES (?, ?, ?)`)
      .bind(user.userId, question, answer || null).run();
    return json({ ok: true });
  }

  if (url.pathname === "/api/ask-ai" && request.method === "POST") {
    const body = await request.json().catch(() => ({}));
    const question = String(body.question || "").trim().slice(0, 2000);
    if (!question) return json({ error: "empty_question", message: "请输入问题。" }, 400);
    if (!env.DEEPSEEK_API_KEY) return json({ error: "deepseek_not_configured", message: "DeepSeek API 密钥尚未配置。" }, 503);

    let response;
    try {
      response = await fetch("https://api.deepseek.com/chat/completions", {
        method: "POST",
        headers: {
          "content-type": "application/json",
          "authorization": `Bearer ${env.DEEPSEEK_API_KEY}`
        },
        body: JSON.stringify({
          model: env.DEEPSEEK_MODEL || "deepseek-flash",
          messages: [
            {
              role: "system",
              content: "你是一名严谨、耐心的公务员考试学习助教。请使用简明准确的中文回答，重点帮助学员理解行测、申论、备考方法与招考常识。讲解题目时给出思路和易错点，不只给结论。对于时政、职位和招考政策，必须提醒学员以官方最新公告为准；不确定时明确说明，不得编造政策、数据或考试规定。"
            },
            { role: "user", content: question }
          ],
          thinking: { type: "disabled" },
          max_tokens: 800,
          temperature: 0.3
        }),
        signal: AbortSignal.timeout(45000)
      });
    } catch (error) {
      console.error("DeepSeek request error", error?.message || error);
      return json({ error: "deepseek_unavailable", message: "AI 服务暂时不可用，请稍后重试。" }, 502);
    }

    if (!response.ok) {
      const detail = await response.text().catch(() => "");
      console.error("DeepSeek API error", response.status, detail.slice(0, 500));
      const message = response.status === 401 ? "DeepSeek API 密钥无效，请检查后重试。" : "AI 服务返回异常，请稍后重试。";
      return json({ error: "deepseek_request_failed", message }, 502);
    }

    const result = await response.json().catch(() => ({}));
    const answer = String(result.choices?.[0]?.message?.content || "").trim().slice(0, 12000);
    if (!answer) return json({ error: "empty_model_answer", message: "AI 暂未生成有效回答，请重新提问。" }, 502);

    await env.DB.prepare(`INSERT INTO ai_questions (user_id, question_text, answer_text) VALUES (?, ?, ?)`)
      .bind(user.userId, question, answer).run();
    return json({ answer, model: result.model || env.DEEPSEEK_MODEL || "deepseek-flash" });
  }

  if (url.pathname === "/api/payments/config" && request.method === "GET") {
    return json({ enabled: false, plan: { code: "lifetime_basic_490", name: "终身基础会员", priceFen: 490 }, methods: { wechat: false, alipay: false } });
  }

  if (url.pathname === "/api/payments/create" && request.method === "POST") {
    const body = await request.json().catch(() => ({}));
    const allowedMethods = new Set(["wechat", "alipay"]);
    if (body.planCode !== "lifetime_basic_490" || !allowedMethods.has(body.method)) return json({ error: "invalid_payment_request" }, 400);
    return json({ error: "payment_provider_not_configured", message: "支付接口暂未接入，当前不会扣款。" }, 503);
  }
  return json({ error: "not_found" }, 404);
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname.startsWith("/api/")) return api(request, env, url);
    const user = await visitor(request, env);
    if (!user || url.pathname === "/login") return new Response(LOGIN_HTML, { headers: { "content-type": "text/html; charset=utf-8", "cache-control": "no-store" } });
    if (url.pathname === "/styles.css") return new Response(CSS, { headers: { "content-type": "text/css; charset=utf-8", "cache-control": "public, max-age=300" } });
    if (url.pathname === "/app.js") return new Response(APP_JS, { headers: { "content-type": "text/javascript; charset=utf-8", "cache-control": "public, max-age=300" } });
    if (url.pathname === "/assets/study-hero-v2.png") return new Response(HERO, { headers: { "content-type": "image/png", "cache-control": "public, max-age=31536000, immutable" } });
    return new Response(HTML, { headers: { "content-type": "text/html; charset=utf-8", "cache-control": "no-cache" } });
  }
};
