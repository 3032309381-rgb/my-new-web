import argparse
import json
import os
from multiprocessing import Pool
from pathlib import Path

import pymupdf
from rapidocr_onnxruntime import RapidOCR


_document = None
_ocr = None
_scale = 1.35


def initialize_worker(pdf_path, scale):
    global _document, _ocr, _scale
    _document = pymupdf.open(pdf_path)
    _ocr = RapidOCR(intra_op_num_threads=1, inter_op_num_threads=1, use_cls=False)
    _scale = scale


def recognize_page(page_index):
    page = _document[page_index]
    pixmap = page.get_pixmap(matrix=pymupdf.Matrix(_scale, _scale), alpha=False)
    result, _ = _ocr(pixmap.tobytes("png"))
    lines = []
    for item in result or []:
        box, text, confidence = item
        lines.append({"text": text, "confidence": round(float(confidence), 4), "box": box})
    return {"page": page_index + 1, "text": "\n".join(line["text"] for line in lines), "lines": lines}


def load_completed(output_path):
    completed = set()
    if not output_path.exists():
        return completed
    with output_path.open("r", encoding="utf-8") as stream:
        for line in stream:
            try:
                completed.add(int(json.loads(line)["page"]))
            except (ValueError, KeyError, json.JSONDecodeError):
                continue
    return completed


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("pdf")
    parser.add_argument("output")
    parser.add_argument("--workers", type=int, default=max(1, min(4, (os.cpu_count() or 2) // 2)))
    parser.add_argument("--scale", type=float, default=1.35)
    parser.add_argument("--end-page", type=int, default=None)
    args = parser.parse_args()

    pdf_path = Path(args.pdf).resolve()
    output_path = Path(args.output).resolve()
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with pymupdf.open(pdf_path) as document:
        total_pages = len(document)
    completed = load_completed(output_path)
    last_page = min(total_pages, args.end_page or total_pages)
    pending = [index for index in range(last_page) if index + 1 not in completed]
    print(f"OCR start: {pdf_path.name}, total={total_pages}, completed={len(completed)}, pending={len(pending)}, workers={args.workers}", flush=True)
    if not pending:
        return

    mode = "a" if output_path.exists() else "w"
    processed = 0
    with output_path.open(mode, encoding="utf-8") as stream, Pool(
        processes=args.workers,
        initializer=initialize_worker,
        initargs=(str(pdf_path), args.scale),
    ) as pool:
        for record in pool.imap_unordered(recognize_page, pending, chunksize=1):
            stream.write(json.dumps(record, ensure_ascii=False) + "\n")
            stream.flush()
            processed += 1
            if processed % 10 == 0 or processed == len(pending):
                print(f"OCR progress: {processed}/{len(pending)} new pages", flush=True)


if __name__ == "__main__":
    main()
