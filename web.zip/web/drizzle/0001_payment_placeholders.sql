CREATE TABLE IF NOT EXISTS plans (
  code TEXT PRIMARY KEY NOT NULL,
  name TEXT NOT NULL,
  price_fen INTEGER NOT NULL,
  is_lifetime INTEGER NOT NULL DEFAULT 0,
  is_active INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

INSERT OR IGNORE INTO plans (code, name, price_fen, is_lifetime, is_active)
VALUES ('lifetime_basic_490', '终身基础会员', 490, 1, 0);

CREATE TABLE IF NOT EXISTS payment_orders (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL,
  plan_code TEXT NOT NULL,
  payment_method TEXT NOT NULL,
  amount_fen INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  provider_order_id TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  paid_at TEXT,
  FOREIGN KEY (user_id) REFERENCES students(user_id) ON DELETE CASCADE,
  FOREIGN KEY (plan_code) REFERENCES plans(code)
);

CREATE TABLE IF NOT EXISTS payment_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id TEXT,
  provider TEXT NOT NULL,
  event_type TEXT NOT NULL,
  provider_event_id TEXT,
  verified INTEGER NOT NULL DEFAULT 0,
  received_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (order_id) REFERENCES payment_orders(id)
);

CREATE TABLE IF NOT EXISTS entitlements (
  user_id TEXT NOT NULL,
  plan_code TEXT NOT NULL,
  granted_by_order_id TEXT,
  starts_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  expires_at TEXT,
  PRIMARY KEY (user_id, plan_code),
  FOREIGN KEY (user_id) REFERENCES students(user_id) ON DELETE CASCADE,
  FOREIGN KEY (plan_code) REFERENCES plans(code),
  FOREIGN KEY (granted_by_order_id) REFERENCES payment_orders(id)
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_payment_events_provider_event
ON payment_events(provider, provider_event_id);
